
import streamlit as st
from prediction_model import get_daily_predictions

st.title("Apex Arc - HR Predictor")

predictions = get_daily_predictions()
st.dataframe(predictions.head(20))
