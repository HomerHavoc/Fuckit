
def get_weather_factor(game_id):
    return 1.05  # simple placeholder
