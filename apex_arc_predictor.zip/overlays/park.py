
def get_park_factor(park_name):
    return 1.2 if park_name == "Coors Field" else 1.0
