import streamlit as st
from prediction_model import run_model

st.title("Apex Arc HR Predictor")

if st.button("Run Prediction"):
    predictions = run_model()
    st.dataframe(predictions)
    st.success("Predictions generated.")
