from prediction_model import run_model
import os

df = run_model()
output_dir = "predictions_output"
os.makedirs(output_dir, exist_ok=True)
df.to_csv(f"{output_dir}/predictions.csv", index=False)
print("Export complete.")
