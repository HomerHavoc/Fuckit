import pandas as pd

def run_model():
    # Dummy example — replace with real logic
    data = {
        "Player": ["Aaron Judge", "Juan Soto"],
        "Predicted HRs": [1.2, 0.8]
    }
    df = pd.DataFrame(data)
    return df
